<?php
/*
Plugin Name: Deals
Description: Declares a plugin that will show companies.
Version: 1.0
Author: Akash
*/
?>

<?php

// disable direct file access
if ( ! defined( 'ABSPATH' ) ) {

    exit;

}


/* Registers the deal post type.  */
function wp_deal_post_type() {

	$labels = array(
		'name'               => __( 'Deals' ),
		'singular_name'      => __( 'Deal' ),
		'add_new'            => __( 'Add New Deal' ),
		'add_new_item'       => __( 'Add New Deal' ),
		'edit_item'          => __( 'Edit Deal' ),
		'new_item'           => __( 'Add New Deal' ),
		'view_item'          => __( 'View Deal' ),
		'search_items'       => __( 'Search Deal' ),
		'not_found'          => __( 'No deals found' ),
		'not_found_in_trash' => __( 'No deals found in trash' )
	);

	$args = array(
		'labels'               => $labels,
		'supports'             => array( 'title', 'editor', 'comments', 'thumbnail', 'custom-fields' ),
		'public'               => true,
		'capability_type'      => 'post',
		'rewrite'              => array( 'slug' => 'deals' ),
		'taxonomies'           => array( '' ),
		'has_archive'          => true,
		'menu_position'        => 15,
		'menu_icon'            => plugins_url( 'images/image.png', __FILE__ ),
		'register_meta_box_cb' => 'wp_deal_metabox',
	);

	register_post_type( 'deals', $args );
}
add_action( 'init', 'wp_deal_post_type' );



/* Add a metabox / custom field box */
 

 function wp_deal_metabox() 

 {
    add_meta_box ( 

    	'deal_meta_box',
        'Company Details',
        'display_deal_meta_box',
        'deals', 
        'normal', 
        'high'
    );
}

add_action( 'admin_init', 'wp_deal_metabox' );


/* Metabox implementation */


function display_deal_meta_box( $deal ) {
 
    $deal_sectors = esc_html( get_post_meta($deal->ID, 'deal_sectors', true ) );
    $deal_launch_year = esc_html( get_post_meta($deal->ID, 'deal_launch_year', true ) );
    $deal_founders = esc_html( get_post_meta($deal->ID, 'deal_founders', true ) );
    $deal_stage = esc_html( get_post_meta($deal->ID, 'deal_stage', true ) );
    $deal_funding_amount= esc_html( get_post_meta($deal->ID, 'deal_funding_amount', true ) );
    $deal_investors = esc_html( get_post_meta($deal->ID, 'deal_investors', true ) );
    $deal_article_title = esc_html( get_post_meta($deal->ID, 'deal_article_title', true ) );
    $deal_link = esc_html( get_post_meta( $deal->ID, 'deal_link', true ) );
    $deal_rating = intval( get_post_meta( $deal->ID, 'deal_rating', true ) );
    ?>

    <table>
        <tr>
            <td style="width: 100%">Sectors</td>
            <td><input type="text" size="80" name="deal_sectors_name" value="<?php echo $deal_sectors; ?>" /></td>
        </tr>

        <tr>
            <td style="width: 100%">Launch Year</td>
            <td><input type="text" size="80" name="deal_launch_year_name" value="<?php echo $deal_launch_year; ?>" /></td>
        </tr>

        <tr>
            <td style="width: 100%">Founders</td>
            <td><input type="text" size="80" name="deal_founders_name" value="<?php echo $deal_founders; ?>" /></td>
        </tr>

        <tr>
            <td style="width: 100%">Stage</td>
            <td><input type="text" size="80" name="deal_stage_name" value="<?php echo $deal_stage; ?>" /></td>
        </tr>


        <tr>
            <td style="width: 100%">Funding Amount</td>
            <td><input type="text" size="80" name="deal_funding_amount_name" value="<?php echo $deal_funding_amount; ?>" /></td>
        </tr>

        <tr>
            <td style="width: 100%">Investors</td>
            <td><input type="text" size="80" name="deal_investors_name" value="<?php echo $deal_investors; ?>" /></td>
        </tr>

        <tr>
            <td style="width: 100%">Article Title</td>
            <td><input type="text" size="80" name="deal_article_title_name" value="<?php echo $deal_article_title; ?>" /></td>
        </tr>

        
        <tr>
            <td style="width: 100%">Link</td>
            <td><input type="url" size="80" name="deal_link_name" value="<?php echo $deal_link; ?>" /></td>
        </tr>

    </table>
    <?php
}
?>

<?php

/* Registering a Save Post Function */

function add_deal_fields( $deal_id, $deal ) {
   
    if ( $deal->post_type == 'deals' ) {
        
        if ( isset( $_POST['deal_sectors_name'] ) && $_POST['deal_sectors_name'] != '' ) {
            update_post_meta( $deal_id, 'deal_sectors', $_POST['deal_sectors_name'] );
        }

        if ( isset( $_POST['deal_launch_year_name'] ) && $_POST['deal_launch_year_name'] != '' ) {
            update_post_meta( $deal_id, 'deal_launch_year', $_POST['deal_launch_year_name'] );
        }

        if ( isset( $_POST['deal_founders_name'] ) && $_POST['deal_founders_name'] != '' ) {
            update_post_meta( $deal_id, 'deal_founders', $_POST['deal_founders_name'] );
        }

        if ( isset( $_POST['deal_stage_name'] ) && $_POST['deal_stage_name'] != '' ) {
            update_post_meta( $deal_id, 'deal_stage', $_POST['deal_stage_name'] );
        }

        if ( isset( $_POST['deal_funding_amount_name'] ) && $_POST['deal_funding_amount_name'] != '' ) {
            update_post_meta( $deal_id, 'deal_funding_amount', $_POST['deal_funding_amount_name'] );
        }


        if ( isset( $_POST['deal_investors_name'] ) && $_POST['deal_investors_name'] != '' ) {
            update_post_meta( $deal_id, 'deal_investors', $_POST['deal_investors_name'] );
        }

        if ( isset( $_POST['deal_article_title_name'] ) && $_POST['deal_article_title_name'] != '' ) {
            update_post_meta( $deal_id, 'deal_article_title', $_POST['deal_article_title_name'] );
        }

        if ( isset( $_POST['deal_link_name'] ) && $_POST['deal_link_name'] != '' ) {
            update_post_meta( $deal_id, 'deal_link', $_POST['deal_link_name'] );
        }
    }
}
add_action( 'save_post', 'add_deal_fields', 10, 2 );


/***** Register a Function to create Template  ******/

function include_template_function( $template_path ) {
    if ( get_post_type() == 'deals' ) {
        if ( is_single() ) {
            
            if ( $theme_file = locate_template( array ( 'single-deals.php' ) ) ) {
                $template_path = $theme_file;
            } else {
                $template_path = plugin_dir_path( __FILE__ ) . '/single-deals.php';
            }
        }
    }
    return $template_path;
}

add_filter( 'template_include', 'include_template_function', 1 );



// Include Stylesheet and Scripts

function wptuts_scripts_important()
{
    
    wp_register_style( 'bootstrap', plugins_url( 'lib/bootstrap/css/bootstrap.css', __FILE__ ) );
   
    wp_enqueue_style( 'bootstrap' );
}
add_action( 'wp_enqueue_scripts', 'wptuts_scripts_important', 5 );

?>


<?php

// Include Shortcode

if ( ! function_exists('deals_shortcode') ) {

    function deals_shortcode() {
    	$deals   .= '<div class="container">';
    	$deals   .= '<div class="row">';          
    	$args   =   array(
                	'post_type'         =>  'deals',
                	'post_status'       =>  'publish',
                	'order' => 'ASC',
                	'posts_per_page' => 4,
    	            );
    	            
        $postslist = new WP_Query( $args );
        global $post;

        if ( $postslist->have_posts() ) :
        $deals   .= '<div class="col-md-3">';

		
            while ( $postslist->have_posts() ) : $postslist->the_post();         
                $deals    .= '<div class="card mb-4 box-shadow" style="border: 2px solid;
    border-radius: 0px;">';
                $deals    .= '<div class="media"  style="border-bottom: 1px solid #000;">';
                $deals    .= '<div><a href="'. the_post_thumbnail('thumbnail', array( 'class' => 'img-responsive mr-0' )) .'"></a></div>';
                $deals    .= '<div class="media-body">';
                $deals    .= '<div class="mt-3 ml-3">';
                $deals    .= '<a href="'.  get_the_title() .'</a>';




                $deals    .= '<a href="'. get_permalink() .'">'. get_the_title() .'</a>';
                $deals    .= '</div>'; 
                $deals    .= '</div>'; 
                $deals    .= '</div>'; 
                $deals    .= '</div>';  
                

            endwhile;
            wp_reset_postdata();
            $deals  .= '</div>';
             $deals  .= '</div>';
              $deals  .= '</div>';

        endif;    
        return $deals;
    }
    add_shortcode( 'deals', 'deals_shortcode' );    
}

?>