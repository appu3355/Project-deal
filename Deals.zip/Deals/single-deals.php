<?php
 /*

 Template Name: Deal Template

 */
 
get_header(); ?>
<div class="album py-5 bg-light">
        <div class="container">

          <div class="row">
    <?php
    $mypost = array( 'post_type' => 'deals', );
    $loop = new WP_Query( $mypost );
    ?>
    <?php while ( $loop->have_posts() ) : $loop->the_post();?>
 
<div class="col-md-3">
              <div class="card mb-4 box-shadow" style="border: 2px solid;
    border-radius: 0px;">
                <div class="media"  style="border-bottom: 1px solid #000;">
                <?php the_post_thumbnail( 'thumbnail', array( 'class' => 'img-responsive mr-0' ) ); ?>
                <div class="media-body">
                <p class="mt-3 ml-3"><?php the_title(); ?></p>
                 <p class="card-text ml-3"><?php echo esc_html( get_post_meta( get_the_ID(), 'deal_sectors', true ) ); ?></p>
                </div>
                </div>
 
                <div class="card-body">
                <p class="card-text"><strong>Launch Year :</strong> <?php echo esc_html( get_post_meta( get_the_ID(), 'deal_launch_year', true ) ); ?></p>
                <p class="card-text"><strong>Founder :</strong> <?php echo esc_html( get_post_meta( get_the_ID(), 'deal_founders', true ) ); ?></p>
                <p class="card-text"><strong>Deal Stage :</strong> <?php echo esc_html( get_post_meta( get_the_ID(), 'deal_stage', true ) ); ?></p>


                <p class="card-text"><strong>Funding Amount :</strong> <?php echo esc_html( get_post_meta( get_the_ID(), 'deal_funding_amount', true ) ); ?></p>
                <p class="card-text"><strong>Investor :</strong> <?php echo esc_html( get_post_meta( get_the_ID(), 'deal_investors', true ) ); ?></p>
                <p class="card-text"><strong>Article Title :</strong> <?php echo esc_html( get_post_meta( get_the_ID(), 'deal_article_title', true ) ); ?></p>
                <p class="card-text"><strong>Link :</strong> <a href="<?php echo the_permalink()?>"><?php echo esc_html( get_post_meta( get_the_ID(), 'deal_link', true ) ); ?></a></p>
                  
                </div>
              </div>
            </div>
    <?php endwhile; ?>
    </div>
</div>
</div>
<?php wp_reset_query(); ?>
<?php get_footer(); ?>